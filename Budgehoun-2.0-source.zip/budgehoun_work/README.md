# Budgehoun 2.0 — projet Android

## Ce qui est inclus
- Refonte visuelle (cartes modernisées, navigation flottante, couleurs et espacements revus).
- Enregistrement des revenus en plus des dépenses.
- Solde net mensuel (revenus moins dépenses) sur le tableau de bord.
- Historique unifié des entrées et sorties, avec modification et suppression.
- Export CSV et rapports enrichis avec les revenus et le solde net.
- Compatibilité de lecture des anciennes sauvegardes : le champ `incomes` est ajouté sans supprimer `expenses`.
- Fonctionnement local hors connexion, sans permission Internet dans le manifeste.

## Compilation automatique (sans installer Android Studio sur ton ordinateur)

Le dépôt contient un workflow GitHub Actions : `.github/workflows/android-apk.yml`.
Après avoir placé le dossier du projet dans un dépôt GitHub, ouvrir l'onglet **Actions**, choisir **Build Budgehoun APK**, puis **Run workflow**. À la fin, télécharger l'artefact **Budgehoun-2.0-debug-apk** : il contient `app-debug.apk`.

Cette compilation est réalisée par GitHub ; elle n'est pas exécutée dans l'environnement ChatGPT. Le fichier APK ne sera disponible qu'après la réussite du workflow.

## Ouvrir et compiler localement
1. Installer Android Studio (version compatible avec Android Gradle Plugin 8.7.3) et Android SDK 35.
2. Ouvrir ce dossier comme projet Gradle.
3. Laisser Gradle synchroniser les dépendances/plugins.
4. Compiler avec **Build > Build APK(s)** ou `gradle :app:assembleDebug`.
5. L'APK debug sera produit dans `app/build/outputs/apk/debug/`.

## Important — migration des données
L'application conserve la clé de stockage WebView `budget-v2` pour reprendre les dépenses existantes si elle est lancée dans le même conteneur d'application. Le nouveau package Android est `com.budgehoun.app` : Android le considère comme une nouvelle application, donc les données de l'ancienne installation ne sont pas automatiquement partagées. Avant de désinstaller l'ancienne version, utiliser **Réglages > Sauvegarde**, puis restaurer le texte dans la nouvelle version.

La sauvegarde exportée par la version 2.0 contient également le tableau `incomes`. Les anciennes sauvegardes sans ce tableau restent acceptées.

## Limites de cette livraison
- Le projet source et le workflow de compilation sont fournis. Aucun APK compilé n'est joint à cette livraison : cet environnement ne dispose pas du SDK Android ni de Gradle, et ne peut pas accéder aux serveurs de téléchargement nécessaires.
- Le chiffrement cryptographique du stockage, l'authentification biométrique et la sauvegarde automatique périodique ne sont pas présentés comme implémentés. Ils nécessitent une migration de stockage native et des tests dédiés.
- Pour une publication, configurer une clé de signature personnelle et effectuer les tests sur plusieurs appareils Android.
